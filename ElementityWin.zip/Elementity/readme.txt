| Elementities |
+--------------+

Elementities is a game about going deeper into cave, fighting against others with your small Elementities, 
creatures which you train like pets, just for fighting and not for sitting and staying.
And why? To get rich and famous, that's why!

[Controls]
[^][v][<][>] - Movement
[Space] - Fire
[1]-[5] - Switch Elementity
[Enter] - Menu
[H] - Open/Close Encyclopedia

[License]
The game itself is copyrighted by Helco under GNU GPL v3.
Excluded are:
 - msvcp110.dll
 - msvcr110.dll
 - vccorlib110.dll
These are copyrighted by Microsoft and are copied from the Microsoft Visual C++ 2012 Redistributable